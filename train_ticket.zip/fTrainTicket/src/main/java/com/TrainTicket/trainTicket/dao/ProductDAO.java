package com.TrainTicket.trainTicket.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.TrainTicket.trainTicket.model.Product;

@Repository
public class ProductDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String TABLE_NAME = "Admin";

	public void addProduct( Product product) {

		String insertSQL = "INSERT INTO " + TABLE_NAME + " (Train_Number,Train_Name, Source, Destination, Fare) VALUES(?,?,?,?,?)";

		jdbcTemplate.update(insertSQL,product.getTrain_Number(), product.getTrain_Name(), product.getSource(), product.getDestination(),
				product.getFare());

	}

	public void editProduct(Product product) {

		String updateSQL = "UPDATE " + TABLE_NAME + " SET Train_Name=?, Source=?, Destination=?, Fare=? WHERE Train_Number=?";

		jdbcTemplate.update(updateSQL, product.getTrain_Name(), product.getSource(), product.getDestination(),
				product.getFare(), product.getTrain_Number());

	}

	public void deleteProduct(int Train_Number) {

		String deleteSQL = "DELETE FROM " + TABLE_NAME + " WHERE Train_Number=?";

		jdbcTemplate.update(deleteSQL, Train_Number);

	}

	public Product getProduct(int Train_Number) {
		String selectByTrain_Number = "SELECT * FROM " + TABLE_NAME + " WHERE Train_Number=?";

		Product product = jdbcTemplate.queryForObject(selectByTrain_Number, new Object[] { Train_Number },
				new BeanPropertyRowMapper<>(Product.class));

		return product;

	}

	public List<Product> getAllProduct() {

		String selectAll = "SELECT * FROM " + TABLE_NAME;

		List<Product> products = jdbcTemplate.query(selectAll, new BeanPropertyRowMapper<>(Product.class));

		return products;

	}

}