package com.TrainTicket.trainTicket.Controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.TrainTicket.trainTicket.model.Product;
import com.TrainTicket.trainTicket.model.Passenger;
import com.TrainTicket.trainTicket.model.Registration;
import com.TrainTicket.trainTicket.model.Ticket;
import com.TrainTicket.trainTicket.model.Train;
import com.TrainTicket.trainTicket.repository.RegRep;
import com.TrainTicket.trainTicket.Service.TrainService;



import com.TrainTicket.trainTicket.Service.ProductService;

import org.springframework.data.repository.CrudRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;





@Controller
public class HomeController {

	@Autowired
	private TrainService trainService;
	@Autowired
	private ProductService productService;
	@Autowired
	private com.TrainTicket.trainTicket.repository.RegRep repo;
	@Autowired
	private BCryptPasswordEncoder bp;
	
	@GetMapping("/")
	public String getFirstPage() {
		return "first";
	}
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/register")
	public String register() {
		
		return "register";
	}
	
	@PostMapping("/register")
	public String reg(@ModelAttribute Registration u,HttpSession session) {
		System.out.println(u);
		u.setPassword(bp.encode(u.getPassword()));
		u.setRole("ROLE_USER");
		repo.save(u);
		return "first";
	}
	@GetMapping("/Adminlog")
	public String getAdminlog() {
		return "Adminlog";
	}
	

	 /* admin */
	
	@GetMapping("/adminindex")
	public String getAdminindex() {
		return "Adminindex";
	}
	
	@GetMapping("/addProduct")
	public String getAddProductPage() {
		return "AddProduct";
	}

	@PostMapping("/addProduct")
	public String addProduct(Product product) {

		// save Product in DB
		productService.saveProduct(product);

		return "redirect:/displayProducts";

	}

	@GetMapping("/displayProducts")
	public ModelAndView getAllProducts() {

		List<Product> allProduct = productService.getAllProduct();

		ModelAndView modelAndView = new ModelAndView("DisplayProduct");
		modelAndView.addObject("allProduct", allProduct);

		return modelAndView;
	}

	@GetMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);

		return "redirect:/displayProducts";
	}

	@GetMapping("/editProduct/{id}")
	public ModelAndView editProduct(@PathVariable int id) {

		Product existingProduct = productService.getProduct(id).orElseGet(null);

		ModelAndView modelAndView = new ModelAndView("EditProduct.html");
		modelAndView.addObject("product", existingProduct);

		return modelAndView;
	}

	@PostMapping("/editProduct")
	public String doEditProduct(Product product) {

		productService.editProduct(product);

		return "redirect:/displayProducts";
	}

	
	
	/*user*/
	
	@GetMapping(value = { "/home" })
	public ModelAndView getHomePage() {

		List<Train> allTrains = trainService.getAllTrains();

		ModelAndView modelAndView = new ModelAndView("home");
		modelAndView.addObject("allTrains", allTrains);

		return modelAndView;
	
	}

	@GetMapping("/bookTrain/{trainNo}")
	public ModelAndView getBookTrainPage(@PathVariable int trainNo) {

		Optional<Train> trainOptional = trainService.getTrainByNumber(trainNo);

		ModelAndView modelAndView = new ModelAndView("bookTrain");

		if (trainOptional.isPresent()) {
			Train train = trainOptional.get();
			modelAndView.addObject("train", train);
		}

		return modelAndView;
	}

	@PostMapping("/bookTrain/{trainNo}")
	public ModelAndView doBooking(Passenger passenger, String travelDate, @PathVariable int trainNo) {

		Optional<Train> trainOptional = trainService.getTrainByNumber(trainNo);

		
		ModelAndView modelAndView = new ModelAndView("printTicket");
	

		if (trainOptional.isPresent()) {
			Train train = trainOptional.get();

			DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");

			DateTime dateTime = DateTime.parse(travelDate, formatter);

			int date = dateTime.getDayOfMonth();
			int month = dateTime.getMonthOfYear();
			int year = dateTime.getYear();

			Ticket ticket = new Ticket(new Date(year, month, date), train);

			ticket.addPassenger(passenger.getName(), passenger.getAge(), passenger.getGender(),passenger.getNoofPaas());
			
			ticket.getTotalFare();

			modelAndView.addObject("ticket", ticket);

		}

		return modelAndView;
	}
	@RequestMapping(value = { "/", "/home" })
	public ModelAndView gethomepage() {

		List<Train> allTrains = trainService.getAllTrains();

		ModelAndView modelAndView = new ModelAndView("home");
		modelAndView.addObject("allTrains", allTrains);

		return modelAndView;
	}
	
	 @RequestMapping(value = "/redirect", method = RequestMethod.GET)
	   public String redirect() {
	     
	      return "redirect:first";
	   }
	 @GetMapping("/payment")
		public String getpayment() {
			return "payment";
		}
	 
	
	
}